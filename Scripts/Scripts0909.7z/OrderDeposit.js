var configurl = 'http://123.206.255.74:8089';

$(document).ready(function(e) {
	
	$(".Tabmenu li").eq(0).addClass("on");
		  $(".Tabmenu li").click(function(){
		   $(this).addClass("on");
		   $(".Tabmenu li").not($(this)).removeClass("on");
		   
		   var idx=$(this).index(".Tabmenu li");
			
		   $(".tabDiv .Block").eq(idx).show();
		   $(".tabDiv .Block").not($(".tabDiv .Block").eq(idx)).hide();
		 });
	SetDataRange('BY')
	UserId =   localStorage.getItem("UserId");
     UserName =  localStorage.getItem("RealName")
	   Account= localStorage.getItem("Account")
	 OrganizeId = localStorage.getItem("OrganizeId")
	 HaveManage = (localStorage.getItem('ManagerId')==null ||localStorage.getItem('ManagerId')=="")?false:true;
	 SellerName = localStorage.getItem("SellerName")
	 
	 	bodyHeight = $(window).height();
	headerHeight  = $('header').height()
	footerHeight = $('footer').height()
	var addAreaHeight = $("#operateArea").height()-$("#listContainer").height();
	divHeight = bodyHeight-headerHeight-footerHeight-addAreaHeight
	console.log(addAreaHeight)
	
	GetPersonDepositList();
	GetDepartDepositList();
	
});
        var popup = new auiPopup();
        function showPopup(){
            popup.show(document.getElementById("Screening"));
        }
		
		Date.prototype.Format = function (fmt) { //author: meizz 
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "H+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}


		var PersonDepositJson;
		var DepartDepositJson;

		//Cancel
   function Cancel(){
    $("#Daui-Scree").trigger("click")
   }
		function Query()
		{
			 $("#Daui-Scree").trigger("click")
			GetPersonDepositList();
			GetDepartDepositList();
	
		}
		
		function BindList(data,id)
		{
			$("#"+id+" tr").not(':eq(0)').remove()
			 $.each(data,function(item,value)
			  {
				$("#"+id).append("<tr ><td>"+value.RankingValue+"</td><td >"+value.SellerName+"</td><td >"+value.Accounts+"</td></tr>");
			  }
		  );
						
		}
		function GetPersonDepositList()
		{
//UserName: UserName,
			var json = {UserId:UserId,RptAccountType:'2',RptSellerType: '1',OpFinishFLg:'', StartTime:$("#StartDate").val(),EndTime:$("#EndDate").val(),OrderParam:''};
			var queryJson = JSON.stringify(json);

			 $.ajax({
					type:"get",
					url:configurl+"/api/Report/GetSalesJson",
					data: {queryJson:queryJson},         		
					dataType: "json",
					  success: function (data)
					  {
						console.log(data)
						
					   PersonDepositJson = data;
						 BindList(data,'PersonDeposit');
						},
					   error: function (XMLHttpRequest, textStatus, errorThrown) 
						{
							  console.log(textStatus)
							  console.log(errorThrown);
					  }
				});
			}
			
			function GetDepartDepositList()
		{
//UserName: UserName,
			var json = {UserId:UserId,RptAccountType:'2',RptSellerType: '2',OpFinishFLg:'', StartTime:$("#StartDate").val(),EndTime:$("#EndDate").val(),OrderParam:2};
			var queryJson = JSON.stringify(json);

			 $.ajax({
					type:"get",
					url:configurl+"/api/Report/GetSalesJson",
					data: {queryJson:queryJson},         		
					dataType: "json",
					  success: function (data)
					  {
						console.log(data)
						
					   DepartDepositJson = data;
						 BindList(data,'DepartDeposit');
						},
					   error: function (XMLHttpRequest, textStatus, errorThrown) 
						{
							  console.log(textStatus)
							  console.log(errorThrown);
					  }
				});
			}
			
			
				
			
			function GetJsonByType(id)
			{
				if(id=='PersonDeposit')
				{
					return PersonDepositJson;
				}
				else 
				{
					return DepartDepositJson;
				}
						
		
			}

			function DepositSort(id){
				/* var datajson = GetJsonByType(id);
				console.log(id)
				console.log(datajson)
				if($("#"+id+" th a.ClickA1 img").attr("src")=="images/down.png"){
				 datajson = datajson.sort(function(a,b){return b.Accounts-a.Accounts});
				 $("#"+id+" th a.ClickA1 img").attr("src","images/up.png");
				}
				else
				{
					datajson = datajson.sort(function(a,b){return a.Accounts-b.Accounts});	
					
					$("#"+id+" th a.ClickA1 img").attr("src","images/down.png");
				}
				BindList(datajson,id); */
			}
		