var configurl = 'http://123.206.255.74:8089';

$(document).ready(function(e) {
	
$(".ClickA3").html($(".ClickA3").html().replace('定金','回款'));
$("#DepartFinish").html($("#DepartFinish").html().replace("BillSort('DepartFinish')'","BillSort('DepartFinish')")); 

	$(".Tabmenu li").eq(0).addClass("on");
		  $(".Tabmenu li").click(function(){
		   $(this).addClass("on");
		   $(".Tabmenu li").not($(this)).removeClass("on");
		   
		   var idx=$(this).index(".Tabmenu li");
			
		   $(".tabDiv .Block").eq(idx).show();
		   $(".tabDiv .Block").not($(".tabDiv .Block").eq(idx)).hide();
		 });
	SetDataRange('BY')
	UserId =   localStorage.getItem("UserId");
     UserName =  localStorage.getItem("RealName")
	   Account= localStorage.getItem("Account")
	 OrganizeId = localStorage.getItem("OrganizeId")
	 HaveManage = (localStorage.getItem('ManagerId')==null ||localStorage.getItem('ManagerId')=="")?false:true;
	 SellerName = localStorage.getItem("SellerName")
	 
	 	bodyHeight = $(window).height();
	headerHeight  = $('header').height()
	footerHeight = $('footer').height()
	var addAreaHeight = $("#operateArea").height()-$("#listContainer").height();
	divHeight = bodyHeight-headerHeight-footerHeight-addAreaHeight

	
	GetPersonSaleList(1);
	GetPersonFinishList(1);
	 GetDepartSaleList(1);
	 GetDepartFinishList(1);
});
        var popup = new auiPopup();
        function showPopup(){
            popup.show(document.getElementById("Screening"));
        }
		
		Date.prototype.Format = function (fmt) { //author: meizz 
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "H+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}


		var PersonSaleJson;
		var PersonFinishJson;
		var DepartSaleJson;
		var DepartFinishJson;
		//Cancel
   function Cancel(){
    $("#Daui-Scree").trigger("click")
   }
		function Query()
		{
			 $("#Daui-Scree").trigger("click")
			GetPersonSaleList(1);
			GetPersonFinishList(1);
			GetDepartSaleList(1);
			GetDepartFinishList(1);
		}
		
		function BindList(data,id)
		{
			
			$("#"+id+" tr").not(':eq(0)').remove()
			
			 $.each(data,function(item,value)
			  {
				  if(value.Subscription==null)
					  value.Subscription = 0;
				$("#"+id).append("<tr ><td>"+value.RankingValue+"</td><td >"+value.SellerName+"</td><td >"+value.Accounts+"</td><td >"+value.OrderCount+"</td><td >"+value.Subscription+"</td></tr>");
			  }
		  );
						
		}
		function GetPersonSaleList(OrderParam)
		{
//UserName: UserName,
			var json = {UserId:UserId,RptAccountType:'1',RptSellerType: '1',OpFinishFLg:'', StartTime:$("#StartDate").val(),EndTime:$("#EndDate").val(),OrderParam:OrderParam};
			var queryJson = JSON.stringify(json);

			 $.ajax({
					type:"get",
					url:configurl+"/api/Report/GetSalesJson",
					data: {queryJson:queryJson},         		
					dataType: "json",
					  success: function (data)
					  {
						console.log(data)
						
					   PersonSaleJson = data;
						 BindList(data,'PersonSale');
						},
					   error: function (XMLHttpRequest, textStatus, errorThrown) 
						{
							  console.log(textStatus)
							  console.log(errorThrown);
					  }
				});
			}
			
			function GetPersonFinishList(OrderParam)
		{
//UserName: UserName,
			var json = {UserId:UserId,RptAccountType:'1',RptSellerType: '1',OpFinishFLg:'3', StartTime:$("#StartDate").val(),EndTime:$("#EndDate").val(),OrderParam:OrderParam};
			var queryJson = JSON.stringify(json);

			 $.ajax({
					type:"get",
					url:configurl+"/api/Report/GetSalesJson",
					data: {queryJson:queryJson},         		
					dataType: "json",
					  success: function (data)
					  {
						console.log(data)
						
					   PersonFinishJson = data;
						 BindList(data,'PersonFinish');
						},
					   error: function (XMLHttpRequest, textStatus, errorThrown) 
						{
							  console.log(textStatus)
							  console.log(errorThrown);
					  }
				});
			}
			
			function GetDepartSaleList(OrderParam)
		{
//UserName: UserName,
			var json = {UserId:UserId,RptAccountType:'1',RptSellerType: '2',OpFinishFLg:'', StartTime:$("#StartDate").val(),EndTime:$("#EndDate").val(),OrderParam:OrderParam};
			var queryJson = JSON.stringify(json);

			 $.ajax({
					type:"get",
					url:configurl+"/api/Report/GetSalesJson",
					data: {queryJson:queryJson},         		
					dataType: "json",
					  success: function (data)
					  {
						console.log(data)
						
					   DepartSaleJson = data;
						 BindList(data,'DepartSale');
						},
					   error: function (XMLHttpRequest, textStatus, errorThrown) 
						{
							  console.log(textStatus)
							  console.log(errorThrown);
					  }
				});
			}
			
				function GetDepartFinishList(OrderParam)
		{
//UserName: UserName,
			var json = {UserId:UserId,RptAccountType:'1',RptSellerType: '2',OpFinishFLg:'3', StartTime:$("#StartDate").val(),EndTime:$("#EndDate").val(),OrderParam:OrderParam};
			var queryJson = JSON.stringify(json);

			 $.ajax({
					type:"get",
					url:configurl+"/api/Report/GetSalesJson",
					data: {queryJson:queryJson},         		
					dataType: "json",
					  success: function (data)
					  {
						console.log(data)
						
					   DepartFinishJson = data;
						 BindList(data,'DepartFinish');
						},
					   error: function (XMLHttpRequest, textStatus, errorThrown) 
						{
							  console.log(textStatus)
							  console.log(errorThrown);
					  }
				});
			}
			
			
				
			
			function GetJsonByType(id,OrderParam)
			{
				if(id=='PersonSale')
				{
					GetPersonSaleList(OrderParam)
					return PersonSaleJson;
				}
				else if(id=='PersonFinish')
				{
					GetPersonFinishList(OrderParam)
					return PersonFinishJson;
				}
				else if(id=='DepartSale')
				{
					GetDepartSaleList(OrderParam)
					return DepartSaleJson;
				}
				else if(id=='DepartFinish')
				{
					GetDepartFinishList(OrderParam)
					return DepartFinishJson;
				}			
		
			}

			function MoneySort(id){
				/* var datajson = GetJsonByType(id);
				console.log($("#"+id+" th a.ClickA1 img").attr("src"))
				
				if($("#"+id+" th a.ClickA1 img").attr("src")=="images/down.png"){
					
				 datajson.sort(function(a,b){return b.Accounts-a.Accounts});
				
				 $("#"+id+" th a.ClickA1 img").attr("src","images/up.png");
				}
				else
				{					
					datajson.sort(function(a,b){return a.Accounts-b.Accounts});	
					
					$("#"+id+" th a.ClickA1 img").attr("src","images/down.png");
				}
				
				BindList(datajson,id); */
				var datajson = GetJsonByType(id,1)
				BindList(datajson,id);
				
			}
		//开单
		function BillSort(id){
				/* var datajson = GetJsonByType(id);
			if($("#"+id+" th a.ClickA2 img").attr("src")=="images/down.png"){
					 datajson = datajson.sort(function(a,b){return b.OrderCount-a.OrderCount});
			 $("#"+id+" th a.ClickA2 img").attr("src","images/up.png");
			}
			else
			{
				 datajson = datajson.sort(function(a,b){return a.OrderCount-b.OrderCount});		
				$("#"+id+" th a.ClickA2 img").attr("src","images/down.png");
			}
			BindList(datajson,id); */
			var datajson = GetJsonByType(id,2)
				BindList(datajson,id);
		
		}
		//回款
		function DepositSort(id){
				/* var datajson = GetJsonByType(id);
			if($("#"+id+" th a.ClickA3 img").attr("src")=="images/down.png"){
			 datajson = datajson.sort(function(a,b){return b.Subscription-a.Subscription});
			 $("#"+id+" th a.ClickA3 img").attr("src","images/up.png");
			}
			else
			{
				 datajson = datajson.sort(function(a,b){return a.Subscription-b.Subscription});	
				
				$("#"+id+" th a.ClickA3 img").attr("src","images/down.png");
			}
			BindList(datajson,id); */
			var datajson = GetJsonByType(id,3)
				BindList(datajson,id);
		}